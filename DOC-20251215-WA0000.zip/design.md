# تصميم UI/UX - تطبيق الحب الحقيقي

## 🎨 المفهوم التصميمي

### اللغة البصرية
- **الأسلوب**: Modern Minimalist مع لمسات دافئة
- **الإحساس**: أمان، ثقة، ودفء (خصوصاً للمطلقين والأرامل)
- **الألوان**: 
  - Primary: Deep Teal (#2D5A5A) - يعبر عن الاستقرار
  - Secondary: Warm Coral (#FF6B6B) - يعبر عن الحب والدفء
  - Background: Soft Cream (#FAF8F5)
  - Text: Dark Charcoal (#2C2C2C)

### التصميم الشامل
- **التوجيه**: RTL للعربية، LTR للإنجليزية
- **الخطوط**: 
  - Arabic: Tajawal (عصري وواضح)
  - English: Inter (حديث ومهني)
- **الأيقونات**: Outlined مع filling عند التفعيل
- **الظلال**: Soft shadows للعمق

## 📱 الشاشات الرئيسية

### 1. Splash Screen
```
[Logo التطبيق]
[اسم التطبيق: الحب الحقيقي]
[شريط تحميل]
```

### 2. Age Gate
```
[عنوان: مرحباً بك في الحب الحقيقي]
[نص: هذا التطبيق مخصص للبالغين فقط]
[حقل: تاريخ الميلاد]
[زر: أكد أنك بالغ]
```

### 3. Login/Register
```
[Tabs: تسجيل دخول | إنشاء حساب]

تسجيل الدخول:
- [Google button]
- [Apple button]
- أو [Email field]
- [Password field]
- [Forgot password?]

إنشاء حساب:
- [الاسم المعروض]
- [البريد الإلكتروني]
- [كلمة المرور]
- [تأكيد كلمة المرور]
- [الحالة الاجتماعية: dropdown]
- [عدد الأبناء: slider]
- [موافق على الشروط]
```

### 4. Home (Swiping)
```
[Top bar]
- [Logo] [Question of the day] [Filter icon]

[Card Stack]
- صورة المستخدم (مع blur toggle للأطفال)
- الاسم، العمر، المدينة
- الحالة الاجتماعية + عدد الأطفال
- علامات التوافق

[Bottom actions]
- [Rewind] [Pass] [Super Like] [Like] [Boost]

[Bottom navigation]
- [Home] [Chat] [Community] [Profile]
```

### 5. Chat
```
[Top bar]
- [Back] [صورة الشخص] [الاسم] [الحالة: نشط الآن]

[Messages area]
- فقاعات دردشة (تماماً مثل WhatsApp)
- [Send location button]
- [Report button]

[Bottom]
- [حقل كتابة الرسالة]
- [Send button]
- [Banner Ad] (يظهر كل 30 ثانية)
```

### 6. Community
```
[Top bar]
- [Logo] [Create Post] [Search]

[Tabs]
- [Trending] [Following] [Anonymous]

[Posts]
- صورة المستخدم (أو "مجهول")
- الاسم (أو "مجهول")
- النص + الصورة
- [Like] [Comment] [Share]
- عدد التفاعلات

[Floating button]
- [+ Add Post]
```

### 7. Profile
```
[Cover photo area]
- صورة الغلاف
- صورة الملف الشخصي (دائرية)
- [Edit button]

[User info]
- الاسم، العمر
- الحالة الاجتماعية
- "مع [X] أطفال"
- المدينة

[Photos grid]
- صور المستخدم (مع toggle لصور الأطفال)

[Settings sections]
- [الإعدادات]
- [الخصوصية]
- [الإشعارات]
- [الحساب]
- [المساعدة]
- [تسجيل الخروج]
```

## 🎯 مكونات التصميم

### بطاقات Swipe
```
┌─────────────────────┐
│ [صورة المستخدم]     │
│                     │
│ [الاسم، العمر]      │
│ [المدينة]           │
│                     │
│ [علامات التوافق]    │
│                     │
│ "سؤال اليوم:"       │
│ [السؤال]            │
└─────────────────────┘
```

### Chat Bubbles
```
// رسالتي
┌─────────────────┐
│ [الرسالة]       │
│ [الوقت]    ✓✓  │
└─────────────────┘

// رسالته
┌─────────────────┐
│ [الرسالة]       │
│ [الوقت]         │
└─────────────────┘
```

### Community Post
```
┌─────────────────────────┐
│ [صورة] الاسم • مجهول؟ │
│                         │
│ [نص المنشور]            │
│ [صورة (اختياري)]        │
│                         │
│ ❤️ 12  💬 5  🔗 2       │
│ [Like] [Comment] [Share]│
└─────────────────────────┘
```

## 🌙 Dark Mode

### الألوان
- **Background**: Dark Navy (#1A1A2E)
- **Cards**: Darker Navy (#16213E)
- **Primary**: Light Teal (#4FBDBA)
- **Secondary**: Light Coral (#FF8E8E)
- **Text**: Light Gray (#E0E0E0)

### التطبيق
- جميع الخلفيات تصبح داكنة
- النصوص تصبح فاتحة
- الأيقونات تبقى بنفس الألوان (مع تعديل السطوع)

## 📐 نظام التصميم

### المسافات (Spacing)
- xs: 4px
- sm: 8px
- md: 16px
- lg: 24px
- xl: 32px

### الحواف (Border Radius)
- Small: 8px
- Medium: 12px
- Large: 16px
- Circle: 50%

### الظلال (Shadows)
```
box-shadow: 0 2px 8px rgba(0,0,0,0.1);
box-shadow: 0 4px 16px rgba(0,0,0,0.15);
box-shadow: 0 8px 32px rgba(0,0,0,0.2);
```

## 🎭 حالات التفاعل

### Swipe Cards
- **لمسة**: تكبير خفيف
- **سحب**: تتبع الإصبع مع تدوير البطاقة
- **إعجاب**: حركة إلى اليمين مع ظهور قلب أخضر
- **رفض**: حركة إلى اليسار مع ظهور X حمراء

### الأزرار
- **عادي**: اللون الأساسي
- **ضغط**: أغمق 10%
- **معطل**: رمادي فاتح
- **تحميل**: spinner دائري

### الإشعارات
- **نجاح**: أخضر مع checkmark
- **خطأ**: أحمر مع X
- **تحذير**: أصفر مع !
- **معلومة**: أزرق مع i

## 🎪 الرسوم المتحركة

### الانتقالات
- **صفحة → صفحة**: Slide من اليمين/اليسار
- **Modal**: Slide من الأسفل
- **Tab**: Fade + Slide

### التفاعلات
- **Like**: قلب ينبض (pulse)
- **Match**: احتفال بألوان
- **Super Like**: نجوم تومض
- **Boost**: لهب متحرك

## 📱 التجاوبية

### الأحجام
- **Mobile**: 320px - 768px
- **Tablet**: 768px - 1024px
- **Desktop**: 1024px+

### التكيف
- **Mobile**: بطاقات كاملة العرض
- **Tablet**: بطاقات بحجم وسط
- **Desktop: شبكة 2x2 للبطاقات

## 🎨 الأصول المطلوبة

### الأيقونات
- Logo التطبيق
- بطاقات Swipe (Like, Pass, Super Like)
- أيقونات التنقل (Home, Chat, Community, Profile)
- أيقونات الإجراءات (Report, Block, Share)

### الصور
- صورة افتراضية للمستخدم
- صورة افتراضية للمجتمع
- صور خلفية للتطبيق
- شعارات المتاجر

### الرسوم المتحركة
- Loading animation
- Match celebration
- Super Hour effects
- Success/error states